﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectManagement.Entities.Enums
{
    public enum TaskStatus
    {
        New,
        InProgress,
        QA,
        Completed
    }
}
